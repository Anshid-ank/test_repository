import json
a = {
    "customfield_10065": "{'name': 'Anshid'}"
}

b = json_data = json.loads(a["customfield_10065"].replace("'", "\""))

print(json_data)