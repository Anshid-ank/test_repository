from stock import Trade

trade = Trade()
# trade.set_credentials(
#     client_id="667d108c-f399-405c-96cb-4afa875bbcef",
#     client_secret="32v0kar3bk",
#     redirect_uri="https://localhost",
#     get_code=True
# )

# trade.set_auth_code(code="POryVU")

# trade.get_access_token()

cookie = "ak_bmsc=9DCB13D31F82C3B433D916C067BC7824~000000000000000000000000000000~YAAQDD/LF+0s/PuHAQAAacRS/xPr5/JHGWRVCoKxFHG7/TKAt4baS9ViM0T0BukDq1tMvYERhaHzBv1EiMNGYyLLVohhAXookzJjLMUBa67FUd0+EarfG4IxEONSrK7gZI52mDC6fwnV1pk//eR8hm6miWNXFREVRKZB6xtRoo/qCjGmMHEEeIc79iBZDfHVpk7o4smt+4LoRo3uSZYnMgFYx3j01TmsZ/CVi7xK6Vacg121TpFTTOuHVuO07c5/3OSJumO8VGK3wI26o9dosOLobIhLsTUoYDjS5Ao5h41u6hLKl44JyPWrkvZievHI6Icklf0NGqhj4idkR5fOg3HrZ4fgDRAxVfl3zq3DHuiGQglcF2Rcyg5xn55/wwc=; bm_sv=799936077DB6839124FEFBD556CCFA1D~YAAQDD/LF8Iu/PuHAQAANdtS/xMWMunp7Ig5A0BRvjPxJziEeVz7Ug6s+S1H+5AKN/PIWU9RF+1sZUbfKIdpmVcyUc9e46RBLiXj0MEHPJg0UWr6B2Rf76pjez8VwKdCYVpeXGD5cqAlA3+Xy+R0TK/4zjFkatozq7/KPLa/fOYLW+5EymqHWnZ+aN+sSG9hM6Sa1sI5P+M9JD64VDcvFzW1TXHlCjcxLSgjgImPa+f38EpKQQFJqIq/A6sJsEUAzEQ=~1"

trade.set_cookie(cookie)
trade.get_symbols()
trade.start_trade("NIFTY 50")
