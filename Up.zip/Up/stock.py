import os
import json
import requests
from time import sleep


class Trade:
    def __init__(self):
        filepath = 'config.json'
        fileCheck = os.path.exists(filepath)

        if fileCheck:
            # Read the config file
            with open(filepath, "r") as file:
                event = json.loads(file.read())
                file.close()
            self.event = event
        else:
            print("Config file doesn't Exist")

    def request(self, url, method, headers={}, params={}, payload={}):

        response = requests.request(method, url, headers=headers, params=params, data=payload, timeout=10)
        
        if response.cookies:
            cookies_dict = response.cookies.get_dict()
            latest_cookie_name = list(cookies_dict.keys())[-1]  # get the name of the latest cookie
            latest_cookie_value = cookies_dict[latest_cookie_name]
            self.cookie = f"{latest_cookie_name}={latest_cookie_value}"
            
            with open("cookie.txt", "w") as file:
                file.write(self.cookie)
                file.close()
        
        status_code = response.status_code
        
        json_response = response.json() if status_code == 200 else response.text
        return {
            "status_code": status_code,
            "response": json_response
        }

    def set_credentials(self, client_id, client_secret, redirect_uri=None, get_code=False):
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        if get_code:
            url = self.event["get_auth_code"] + f"response_type=code&client_id={self.client_id}&redirect_uri={self.redirect_uri}"
            print("Auth code url : ", url)

    def set_auth_code(self, code):
        self.code = code

    def set_cookie(self, cookie):
        self.cookie = cookie

    def get_access_token(self):
        url = self.event["base_url"] + self.event["auth"]

        payload = {
            'code': self.code,
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'redirect_uri': self.redirect_uri,
            'grant_type': 'authorization_code'
        }

        headers = {
            'accept': 'application/json',
            'Api-Version': '2.0',
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        response = self.request(url=url, method="POST", headers=headers, payload=payload)
        self.access_token = "123456"
        # if response["status_code"] == 200:
        #     self.access_token = response["response"]["access_token"]
        # else:
        #     raise Exception(f'token generation failed, response: {response}')

    def get_symbols(self):

        url = self.event["get_symbols"]
        header = header = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'Cache-Control': 'max-age=0',
            'Sec-Ch-Ua': '"Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Linux"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299',
            "Cookie": self.cookie
        }
        response = self.request(url=url, method="GET", headers=header)
        # if type(response["response"]) != dict:
        #     raise Exception("Error in loading points")
        with open("symbols.json", "w") as file:
            file.write(json.dumps(response, indent=4))
            file.close()
        print("check the file named symbols.json")

    def start_trade(self, symbol, order=1, losspoint=5,profit_point=5):
        url = self.event["get_points"] + f"symbol={symbol}"
        print("get points : ", url)

        current_price = 0
        order_placed = False

        header = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'Cache-Control': 'max-age=0',
            'Sec-Ch-Ua': '"Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Linux"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299',
            "Cookie": self.cookie
        }
        while order:
            response = self.request(url=url, method="GET", headers=header)
            if type(response["response"]) != dict:
                print("Error in getting the data points")
                sleep(30)
                continue

            with open("points.json", "a") as file:
                file.write(json.dumps(response, indent=4))
                file.close

            previous_price = current_price
            current_price = response["response"]["priceInfo"]["lastPrice"]

            lowest = response["response"]["priceInfo"]["intraDayHighLow"]["min"]
            highest = response["response"]["priceInfo"]["intraDayHighLow"]["max"]

            if not order_placed and previous_price:
                if current_price > previous_price:
                    method = "CALL"
                    order_placed_point = current_price
                    print("order placed CALL", current_price)
                    order_placed = True
                elif current_price < previous_price:
                    method = "PUT"
                    order_placed_point = current_price
                    print("order placed PUT", current_price)
                    order_placed = True

            if order_placed and method == "CALL" and (current_price < order_placed_point-losspoint or current_price > order_placed_point + profit_point):
                print("order withdraw , method : CALL", current_price)
                order -= 1
            
            if order_placed and method == "PUT" and (current_price < order_placed_point-profit_point or current_price > order_placed_point + losspoint):
                print("order withdraw, method : PUT", current_price)
                order -= 1
            
            if order:
                sleep(60)
            else:
                print("Exit trade")

    def print_credentials(self):
        return self.client_id
